USE CloudPlanning;
GO

SELECT * FROM usuario

SELECT * FROM usuarioComum

SELECT * FROM empresa

SELECT * FROM diagrama

SELECT * FROM Componentes

