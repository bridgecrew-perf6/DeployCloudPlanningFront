USE CloudPlanning;
GO


INSERT INTO usuario (email, senha) 
VALUES 
GO


INSERT INTO usuarioComum (idUsuario, idEmpresa, nome, CPF, DataNascimento)
VALUES 
GO


INSERT INTO empresa (idUsuario, CNPJ, nomeFantasia, telefone)
VALUES 
GO


INSERT INTO diagrama (idEmpresa, idComponentes, nome)
VALUES 
GO


INSERT INTO Componentes (nome, codigo, imagemComponente, descricao)
VALUES 
GO
