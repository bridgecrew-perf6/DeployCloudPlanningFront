# CloudPlanning
Projeto final integrado realizado no SENAI-SP, sistema responsável em um ambiente de cadastramento de clientes e sua infraestrutura aws. 
